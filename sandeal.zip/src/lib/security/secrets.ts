// ===========================================
// Secret Handling — Encryption, Decryption, Masking
// ===========================================
// Server-side only. Never import from client components.
// Uses Node.js crypto with AES-256-GCM.
// Falls back to base64 if TOKEN_VAULT_SECRET_KEY is not set.

import { createCipheriv, createDecipheriv, randomBytes, scryptSync } from 'crypto';
import type { StoredCredential, SafeCredential } from '../types/tokenVault';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const TAG_LENGTH = 16;
const SALT = 'sandeal-token-vault-salt-v1';

// ---- Secret Key Management ----

function getEncryptionKey(): Buffer | null {
  const envKey = process.env.TOKEN_VAULT_SECRET_KEY;
  if (!envKey || envKey === 'change_me_to_a_long_random_secret' || envKey.length < 16) {
    return null;
  }
  // Derive a 32-byte key from the env secret using scrypt
  return scryptSync(envKey, SALT, 32);
}

let hasWarnedNoKey = false;

function warnNoKey(): void {
  if (!hasWarnedNoKey) {
    console.warn(
      '[Token Vault] TOKEN_VAULT_SECRET_KEY chưa được cấu hình hoặc quá ngắn. ' +
      'Dùng base64 encoding thay vì mã hoá thật. Hãy đặt TOKEN_VAULT_SECRET_KEY trong .env.'
    );
    hasWarnedNoKey = true;
  }
}

// ---- Encryption ----

/**
 * Encrypt a secret value.
 * Uses AES-256-GCM if TOKEN_VAULT_SECRET_KEY is set.
 * Falls back to base64 encoding with a marker prefix.
 */
export function encryptSecret(value: string): string {
  const key = getEncryptionKey();
  if (!key) {
    warnNoKey();
    // Fallback: base64 with prefix marker
    return `b64:${Buffer.from(value, 'utf-8').toString('base64')}`;
  }

  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(ALGORITHM, key, iv);
  const encrypted = Buffer.concat([cipher.update(value, 'utf-8'), cipher.final()]);
  const tag = cipher.getAuthTag();

  // Format: enc:<iv>:<tag>:<encrypted> (all hex)
  return `enc:${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

/**
 * Decrypt a secret value.
 * Handles both AES-256-GCM encrypted values and base64 fallback.
 */
export function decryptSecret(encrypted: string): string {
  // Handle base64 fallback
  if (encrypted.startsWith('b64:')) {
    return Buffer.from(encrypted.slice(4), 'base64').toString('utf-8');
  }

  // Handle AES-256-GCM
  if (!encrypted.startsWith('enc:')) {
    // Legacy plain value — should not happen but handle gracefully
    return encrypted;
  }

  const key = getEncryptionKey();
  if (!key) {
    throw new Error(
      'Không thể giải mã token: TOKEN_VAULT_SECRET_KEY chưa được cấu hình. ' +
      'Token này đã được mã hoá bằng AES nhưng không tìm thấy khoá giải mã.'
    );
  }

  const parts = encrypted.slice(4).split(':');
  if (parts.length !== 3) {
    throw new Error('Dữ liệu mã hoá không hợp lệ.');
  }

  const iv = Buffer.from(parts[0], 'hex');
  const tag = Buffer.from(parts[1], 'hex');
  const encryptedData = Buffer.from(parts[2], 'hex');

  const decipher = createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);
  const decrypted = Buffer.concat([decipher.update(encryptedData), decipher.final()]);

  return decrypted.toString('utf-8');
}

// ---- Masking ----

/**
 * Mask a secret for safe frontend display.
 * Shows first 4 and last 4 characters, masks middle.
 * 
 * Examples:
 * - "AIzaSyABCDEF123456" → "AIza****3456"
 * - "EAABwzLixnjYBO..." → "EAAB****YBO."
 * - Short values → "****"
 */
export function maskSecret(value: string): string {
  if (!value) return '';
  const trimmed = value.trim();
  if (trimmed.length <= 8) return '****';
  const prefix = trimmed.slice(0, 4);
  const suffix = trimmed.slice(-4);
  return `${prefix}****${suffix}`;
}

// ---- Safe Projection ----

/**
 * Strip sensitive fields from a StoredCredential.
 * Returns a SafeCredential that is safe for frontend/API responses.
 * NEVER includes encryptedValue.
 */
export function toSafeCredential(stored: StoredCredential): SafeCredential {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { encryptedValue, ...safe } = stored;
  return safe;
}

/**
 * Strip sensitive fields from an array of StoredCredentials.
 */
export function toSafeCredentials(stored: StoredCredential[]): SafeCredential[] {
  return stored.map(toSafeCredential);
}
